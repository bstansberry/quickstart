package org.jboss.as.quickstarts.resteasyspring;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

/**
 * @author Tomaz Cerar (c) 2017 Red Hat Inc.
 */
@ApplicationPath("/")
public class JaxRsActivator extends Application {
}
